#include<stdio.h>
#include<stdlib.h>
#define OK 1
#define ERROR 0
typedef int Elemtype,Status;
typedef struct node
{
	Elemtype element;
	struct Node *link;
}Node;
typedef struct
{
	struct Node *first;
	int n;
}Singlelist;
typedef struct
{
	Node *head;
	int n;
}Headerlist;
Status Init(Headerlist *h)
{
	h->head=(Node*)malloc(sizeof(Node));
	if(!h->head)return ERROR;
	h->head->link=NULL;
	h->n=0;
	return OK;
}
Status Insert(Headerlist *h,int i,Elemtype x)
{
	int j;
	Node *p,*q;
	if(!h->n)return ERROR;
	p=h->head;
	for(j=0;j<=i;j++)p=p->link;
}
int main()
{
}